var db = require("../models");
var express = require("express");
var router = express.Router();

module.exports = function (app) {

  app.get("/", function (req, res) {
    console.log("in")
    var arr = [];
    db.Burger.findAll({}).then(function (resp) {
      console.log(resp);
      for (var i = 0; i < resp.length; i++) {
        arr.push(resp[i].dataValues);
      }
      res.render("index", { burgers: arr })
    });
  });

  // app.post("/api/burgers", function (req, res) {

  // });

  // app.put("/api/burgers", function (req, res) {

  // });

}